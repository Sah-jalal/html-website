$(document).ready(function(){
    $('#tumar').click(function(){
        $('#hide-btn').addClass('sahjalal')
    })
})